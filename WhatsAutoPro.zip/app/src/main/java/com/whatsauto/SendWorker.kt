package com.whatsauto

import android.content.Context
import android.content.Intent
import androidx.work.Worker
import androidx.work.WorkerParameters

class SendWorker(context: Context, params: WorkerParameters)
: Worker(context,params){

override fun doWork(): Result {

val intent = applicationContext.packageManager
.getLaunchIntentForPackage("com.whatsapp")

intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

applicationContext.startActivity(intent!!)

return Result.success()

}

}