package com.whatsauto

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class MainActivity : AppCompatActivity() {

override fun onCreate(savedInstanceState: Bundle?) {

super.onCreate(savedInstanceState)

setContentView(R.layout.activity_main)

val btn = findViewById<Button>(R.id.scheduleBtn)

btn.setOnClickListener {

Scheduler.schedule(this,60000)

}

}

}