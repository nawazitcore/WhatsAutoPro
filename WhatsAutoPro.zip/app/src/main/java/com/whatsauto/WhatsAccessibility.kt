package com.whatsauto

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class WhatsAccessibility: AccessibilityService(){

override fun onAccessibilityEvent(event: AccessibilityEvent?) {

val root = rootInActiveWindow ?: return

val sendNodes = root.findAccessibilityNodeInfosByText("Send")

if(sendNodes.isNotEmpty()){

sendNodes[0].performAction(
AccessibilityNodeInfo.ACTION_CLICK
)

}

}

override fun onInterrupt() {}

}