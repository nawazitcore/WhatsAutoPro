package com.whatsauto

import android.content.Context
import androidx.work.*

import java.util.concurrent.TimeUnit

object Scheduler {

fun schedule(context: Context, delay: Long){

val work = OneTimeWorkRequestBuilder<SendWorker>()
.setInitialDelay(delay,TimeUnit.MILLISECONDS)
.build()

WorkManager.getInstance(context).enqueue(work)

}

}